# ソースコードの配布

`setup.py`でパッケージ化してソースコードを配布する。

```sh
python setup.py sdist
```
