from setuptools import setup

setup(
    name='package',
    version='1',
    packages=['my_package'],
    url='https://github.com/121jigowatts',
    license='free',
    author='soil',
    author_email='',
    description='python demo'
)