def some_func(word):
    return (word + '!') * 3
